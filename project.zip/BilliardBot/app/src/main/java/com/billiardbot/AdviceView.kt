package com.billiardbot

import android.content.Context
import android.graphics.*
import android.view.View

/** Full-screen, touch-transparent layer that draws the recommended shot on top of the game. */
class AdviceView(ctx: Context, private val cal: Calib) : View(ctx) {
    private var adv: Advice? = null
    private var lines: List<String> = emptyList()
    private val line = Paint().apply { color = Ov.COLOR; style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = false }
    private val dash = Paint(line).apply { pathEffect = DashPathEffect(floatArrayOf(14f, 14f), 0f) }
    private val thick = Paint(line).apply { strokeWidth = 9f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.RIGHT }
    private val bg = Paint().apply { color = 0xCC000000.toInt() }

    fun set(a: Advice?, l: List<String>) { adv = a; lines = l; invalidate() }

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val r = cal.ball
        val a = adv
        if (a != null) {
            c.drawLine(a.cue.x, a.cue.y, a.gh.x, a.gh.y, dash)
            c.drawCircle(a.gh.x, a.gh.y, r, line)
            for ((p, q) in a.legs) c.drawLine(p.x, p.y, q.x, q.y, line)
            a.pocket?.let { c.drawCircle(it.x, it.y, r * 0.7f, line) }
            // power marker on the power bar
            val px = cal.pTopX + (cal.pBotX - cal.pTopX) * a.power
            val py = cal.pTopY + (cal.pBotY - cal.pTopY) * a.power
            c.drawLine(px - 32f, py, px + 32f, py, thick)
            val ts = (cal.r - cal.l) * 0.045f
            txt.textSize = ts; txt.textAlign = Paint.Align.LEFT
            val label = "${(a.power * 100).toInt()}%"
            val w = txt.measureText(label)
            c.drawRect(px + 38f, py - ts, px + 50f + w, py + ts * 0.35f, bg)
            c.drawText(label, px + 44f, py, txt)
        }
        if (lines.isNotEmpty()) {
            val ts = (cal.r - cal.l) * 0.05f
            txt.textSize = ts; txt.textAlign = Paint.Align.RIGHT
            val h = lines.size * ts * 1.4f + 16f
            val top = maxOf(6f, cal.t - h - 12f)
            c.drawRect(cal.l, top, cal.r, top + h, bg)
            var y = top + ts * 1.15f
            for (s in lines) { c.drawText(s, cal.r - 12f, y, txt); y += ts * 1.4f }
        }
    }
}
