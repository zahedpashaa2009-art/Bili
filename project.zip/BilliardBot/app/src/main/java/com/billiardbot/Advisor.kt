package com.billiardbot

import kotlin.math.abs
import kotlin.math.roundToInt

/** Watches the screen, and after every shot works out the best shot and shows it. Never touches the game. */
class Advisor(private val svc: OverlayService, private val cal: Calib) {
    @Volatile var running = false
    @Volatile private var altIdx = 0
    @Volatile private var list: List<Advice> = emptyList()
    private var th: Thread? = null

    fun next() { val n = list.size; if (n > 1) altIdx = (altIdx + 1) % n }

    fun start() {
        if (running) return
        running = true
        th = Thread {
            try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { svc.say("خطا: ${e.message}") }
            running = false
            svc.onAdvisorStopped()
        }.also { it.start() }
    }

    fun stop() { running = false; th?.interrupt(); list = emptyList(); svc.show(null, emptyList()) }

    private fun wrap(d: Double): Double { var x = d; while (x > 180) x -= 360; while (x < -180) x += 360; return x }

    private fun loop() {
        var prevSig = Double.NaN; var stable = 0
        var plannedSig = Double.NaN
        while (running) {
            val f = svc.capture.grab()
            if (f == null) { Thread.sleep(300); continue }
            val balls = Vision.detect(f, cal)
            val cue = balls.firstOrNull { it.kind == 0 }
            if (cue == null) {
                list = emptyList(); plannedSig = Double.NaN; prevSig = Double.NaN; stable = 0
                svc.show(null, listOf("توپ سفید پیدا نشد (ضربه در جریان است؟)"))
                Thread.sleep(400); continue
            }
            val sig = balls.sumOf { it.x.toDouble() + it.y.toDouble() * 1.3 } + balls.size * 10000.0
            stable = if (!prevSig.isNaN() && abs(sig - prevSig) < 1.5) stable + 1 else 0
            prevSig = sig

            if (plannedSig.isNaN() || abs(sig - plannedSig) > 3.0) {
                if (stable >= 2) {
                    val geo = Geo(cal.l, cal.t, cal.r, cal.b, cal.ball)
                    list = Planner.rank(cue, balls, cal.mode, geo, cal.powerScale)
                    altIdx = 0
                    plannedSig = sig
                } else {
                    list = emptyList()
                    svc.show(null, listOf("در حال حرکت توپ‌ها…"))
                }
            }

            val l = list
            if (l.isNotEmpty()) {
                val a = l[altIdx.coerceIn(0, l.size - 1)]
                val lines = ArrayList<String>()
                lines.add("شات ${altIdx + 1} از ${l.size}:  ${a.title}")
                lines.add("سختی: ${a.hard}   |   قدرت ≈ ${(a.power * 100).roundToInt()}٪")
                val cur = Vision.aimAngle(f, cue, cal.ball, a.angle)
                if (cur != null) {
                    val err = wrap(Math.toDegrees(a.angle.toDouble()) - Math.toDegrees(cur.toDouble()))
                    lines.add(if (abs(err) < 0.2) "✔ زاویه دقیق است، بزن!"
                    else "زاویه را %.1f° %s بچرخان".format(abs(err), if (err > 0) "ساعت‌گرد ↻" else "پادساعت‌گرد ↺"))
                }
                svc.show(a, lines)
            }
            Thread.sleep(200)
        }
    }
}
