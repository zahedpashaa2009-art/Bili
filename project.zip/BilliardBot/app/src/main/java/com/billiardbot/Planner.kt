package com.billiardbot

import kotlin.math.*

class Pk(val name: String, val pos: P, val axis: P, val side: Boolean)

class Geo(val l: Float, val t: Float, val r: Float, val b: Float, val rad: Float) {
    val il = l + rad; val it = t + rad; val ir = r - rad; val ib = b - rad
    val cy = (t + b) / 2
    val diag = hypot(r - l, b - t)
    val pockets = listOf(
        Pk("بالا-چپ", P(l, t), P(-1f, -1f).norm(), false), Pk("بالا-راست", P(r, t), P(1f, -1f).norm(), false),
        Pk("پایین-چپ", P(l, b), P(-1f, 1f).norm(), false), Pk("پایین-راست", P(r, b), P(1f, 1f).norm(), false),
        Pk("وسط-چپ", P(l, cy), P(-1f, 0f), true), Pk("وسط-راست", P(r, cy), P(1f, 0f), true)
    )
}

class Cand(
    val gh: P, val ball: Ball, val score: Float, val bank: Boolean,
    val d1: Float, val d2: Float, val cutSin: Float, val u: P, val dir: P,
    val pk: Pk, val legs: List<Pair<P, P>>
)

object Planner {
    private fun segDist(p: P, a: P, b: P): Float {
        val ab = b - a; val l2 = ab.dot(ab)
        if (l2 < 1e-6f) return (p - a).len()
        val t = ((p - a).dot(ab) / l2).coerceIn(0f, 1f)
        return (p - (a + ab * t)).len()
    }

    fun targetsFor(objs: List<Ball>, mode: Int): List<Ball> {
        val own = when (mode) {
            0 -> objs.filter { it.kind == 1 }
            1 -> objs.filter { it.kind == 2 }
            else -> objs.filter { it.kind == 1 || it.kind == 2 }
        }
        return if (own.isEmpty()) objs.filter { it.kind == 3 } else own
    }

    private fun make(cue: P, tb: Ball, aimPt: P, legs: List<Pair<P, P>>, obs: List<P>, g: Geo, pk: Pk, bank: Boolean): Cand? {
        val b = tb.p; val r = g.rad
        val u = (aimPt - b).norm()
        val gh = b - u * (2 * r)
        if (gh.x < g.il - r || gh.x > g.ir + r || gh.y < g.it - r || gh.y > g.ib + r) return null
        val dir = (gh - cue).norm()
        val cos = dir.dot(u)
        if (cos < (if (bank) 0.5f else 0.34f)) return null
        val d1 = (gh - cue).len()
        if (d1 < 2.5f * r) return null
        for (o in obs) if (segDist(o, cue, gh) < 2 * r - 1.5f) return null
        for ((a, c) in legs) for (o in obs) if (segDist(o, a, c) < 2 * r - 1.5f) return null
        val last = legs.last()
        val entry = (last.second - last.first).norm().dot(pk.axis)
        if (entry < 0.5f) return null
        val d2 = legs.sumOf { (it.second - it.first).len().toDouble() }.toFloat()
        val cutSin = sqrt(max(0f, 1f - cos * cos))
        var score = cos.pow(1.3f) * entry / (1f + (d1 + d2) / (g.diag * 0.9f))
        if (pk.side) score *= 0.9f
        if (bank) score *= 0.45f
        return Cand(gh, tb, score, bank, d1, d2, cutSin, u, dir, pk, legs)
    }

    fun cands(cue: P, objs: List<Ball>, targets: List<Ball>, g: Geo): List<Cand> {
        val out = ArrayList<Cand>()
        for (tb in targets) {
            val b = tb.p
            val obs = objs.filter { it !== tb }.map { it.p }
            for (pk in g.pockets) {
                make(cue, tb, pk.pos, listOf(b to pk.pos), obs, g, pk, false)?.let { out.add(it) }
                for (w in 0..3) {
                    val pm = when (w) {
                        0 -> P(2 * g.il - pk.pos.x, pk.pos.y)
                        1 -> P(2 * g.ir - pk.pos.x, pk.pos.y)
                        2 -> P(pk.pos.x, 2 * g.it - pk.pos.y)
                        else -> P(pk.pos.x, 2 * g.ib - pk.pos.y)
                    }
                    val t = when (w) {
                        0 -> (g.il - b.x) / (pm.x - b.x)
                        1 -> (g.ir - b.x) / (pm.x - b.x)
                        2 -> (g.it - b.y) / (pm.y - b.y)
                        else -> (g.ib - b.y) / (pm.y - b.y)
                    }
                    if (t.isNaN() || t <= 0.05f || t >= 0.95f) continue
                    val h = b + (pm - b) * t
                    if (h.x < g.il - 1 || h.x > g.ir + 1 || h.y < g.it - 1 || h.y > g.ib + 1) continue
                    make(cue, tb, pm, listOf(b to h, h to pk.pos), obs, g, pk, true)?.let { out.add(it) }
                }
            }
        }
        return out
    }

    /** One-step lookahead: roughly where the cue ball ends up, and how good the next shot is from there. */
    private fun follow(c: Cand, objs: List<Ball>, mode: Int, g: Geo): Float {
        val rest = objs.filter { it !== c.ball }
        val t = c.dir - c.u * c.dir.dot(c.u)
        var fc = if (t.len() < 1e-3f) c.gh else c.gh + t.norm() * (c.cutSin * g.rad * 9f)
        fc = P(fc.x.coerceIn(g.il, g.ir), fc.y.coerceIn(g.it, g.ib))
        val tg = targetsFor(rest, mode)
        if (tg.isEmpty()) return 0.3f
        return cands(fc, rest, tg, g).maxOfOrNull { it.score } ?: -0.15f
    }

    private fun power(d1: Float, d2: Float, bank: Boolean, g: Geo, scale: Float): Float {
        val tot = d1 + d2 * (if (bank) 1.2f else 1f)
        return (0.2f + 0.8f * (tot / (g.diag * 1.1f)) * scale).coerceIn(0.15f, 1f)
    }

    private fun safe(cue: Ball, objs: List<Ball>, targets: List<Ball>, g: Geo): Advice {
        val r = g.rad
        val sorted = targets.sortedBy { (it.p - cue.p).len() }
        val tgt = sorted.firstOrNull { t -> objs.none { o -> o !== t && segDist(o.p, cue.p, t.p) < 2 * r } }
            ?: sorted.firstOrNull() ?: objs.first()
        val dir = (tgt.p - cue.p).norm()
        return Advice(cue.p, tgt.p - dir * (2 * r), tgt.p, emptyList(), null, 0.4f,
            atan2(tgt.y - cue.y, tgt.x - cue.x), "دفاعی (امن)", "—")
    }

    /** Ranked list of advice, best first. */
    fun rank(cue: Ball, balls: List<Ball>, mode: Int, g: Geo, ps: Float): List<Advice> {
        val objs = balls.filter { it.kind != 0 }
        if (objs.isEmpty()) return emptyList()
        val r = g.rad

        if (objs.size >= 7) {
            val mx = objs.map { it.x }.average().toFloat(); val my = objs.map { it.y }.average().toFloat()
            if (objs.all { hypot(it.x - mx, it.y - my) < 5.5f * r }) {
                val t = objs.minByOrNull { (it.p - cue.p).len() }!!
                val dir = (t.p - cue.p).norm()
                return listOf(Advice(cue.p, t.p - dir * (2 * r), t.p, emptyList(), null, 1f,
                    atan2(t.y - cue.y, t.x - cue.x), "ضربه شروع (Break)", "—"))
            }
        }

        val targets = targetsFor(objs, mode)
        val cs = cands(cue.p, objs, targets, g)
        val scored = cs.map { it to (it.score + 0.45f * follow(it, objs, mode, g)) }.sortedByDescending { it.second }
        val out = ArrayList<Advice>()
        for ((c, _) in scored.take(6)) {
            val hard = if (c.score > 0.40f) "آسان" else if (c.score > 0.22f) "متوسط" else "سخت"
            val title = (if (c.bank) "بانک" else "مستقیم") + " ← جیب " + c.pk.name + (if (c.ball.kind == 3) " (توپ ۸)" else "")
            out.add(Advice(cue.p, c.gh, c.ball.p, c.legs, c.legs.last().second,
                power(c.d1, c.d2, c.bank, g, ps), atan2(c.gh.y - cue.y, c.gh.x - cue.x), title, hard))
        }
        if (out.isEmpty() || scored.first().first.score < 0.08f) {
            val s = safe(cue, objs, targets, g)
            if (out.isEmpty()) out.add(s) else out.add(0, s)
        }
        return out
    }
}
