package com.billiardbot

import android.content.Context

class Calib(ctx: Context) {
    private val sp = ctx.getSharedPreferences("calib", Context.MODE_PRIVATE)
    var l = 0f; var t = 0f; var r = 0f; var b = 0f
    var pTopX = 0f; var pTopY = 0f; var pBotX = 0f; var pBotY = 0f
    var ball = 0f
    var mode = 0            // 0 solids, 1 stripes, 2 any
    var powerScale = 1f

    init { load() }

    fun load() {
        l = sp.getFloat("l", 0f); t = sp.getFloat("t", 0f); r = sp.getFloat("r", 0f); b = sp.getFloat("b", 0f)
        pTopX = sp.getFloat("ptx", 0f); pTopY = sp.getFloat("pty", 0f)
        pBotX = sp.getFloat("pbx", 0f); pBotY = sp.getFloat("pby", 0f)
        ball = sp.getFloat("ball", 0f)
        mode = sp.getInt("mode", 0)
        powerScale = sp.getFloat("ps", 1f)
    }

    fun save() {
        sp.edit()
            .putFloat("l", l).putFloat("t", t).putFloat("r", r).putFloat("b", b)
            .putFloat("ptx", pTopX).putFloat("pty", pTopY).putFloat("pbx", pBotX).putFloat("pby", pBotY)
            .putFloat("ball", ball).putInt("mode", mode).putFloat("ps", powerScale)
            .apply()
    }

    val ready: Boolean
        get() = r > l + 50 && b > t + 50 && ball > 4f && (pBotX != pTopX || pBotY != pTopY)
}
